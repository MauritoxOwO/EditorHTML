/*
*This is auto generated from the ControlManifest.Input.xml file
*/

// Define IInputs and IOutputs Type. They should match with ControlManifest.
export interface IInputs {
    htmlContent: ComponentFramework.PropertyTypes.StringProperty;
    entityName: ComponentFramework.PropertyTypes.StringProperty;
    fieldName: ComponentFramework.PropertyTypes.StringProperty;
}
export interface IOutputs {
    htmlContent?: string;
    entityName?: string;
    fieldName?: string;
}
